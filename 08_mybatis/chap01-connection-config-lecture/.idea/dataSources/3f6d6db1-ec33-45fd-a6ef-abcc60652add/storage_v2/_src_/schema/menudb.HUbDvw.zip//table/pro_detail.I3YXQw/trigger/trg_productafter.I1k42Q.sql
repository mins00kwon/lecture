create definer = root@localhost trigger trg_productafter
    after insert
    on pro_detail
    for each row
BEGIN 
	IF NEW.status='입고' THEN
		UPDATE product 
			SET stock=stock+NEW.amount
		WHERE pcode=NEW.pcode;
	ELSEIF NEW.status='출고'THEN
		UPDATE product 
			SET stock=stock-NEW.amount
		WHERE pcode=NEW.pcode;
	END IF;
END;

